#include "queue.h"

// TYPE * _arr;     // pointer to dynamic integer array
// int _front;      // index to the front element of queue
// int _size;       // number of current elements in queue
// int _capacity;   // current capacity


queue::queue(int) {
  _arr = new TYPE[INITCAP];
  _front = 0;
  _size = 0;
  _capacity = INITCAP;
}

// copy constructor
queue::queue(const queue& arty) {
   //  _arr = arty._arr;
  _arr = new TYPE[arty._capacity];
  _capacity = arty._capacity;
  _front = arty._front;
  _size = arty._size;
  for (int i = 0; i < _capacity; i++) {
    _arr[i] = arty._arr[i];
  }
}

// assignment operator
queue& queue::operator=(const queue& arty) {
  delete [] _arr;
  _arr = arty._arr;
  _arr = new TYPE[arty._capacity];
  _capacity = arty._capacity;
  _front = arty._front;
  _size = arty._size;
  for (int i = 0; i < _capacity; i++) {
    _arr[i] = arty._arr[i];
  }
  return *this;
}

// destructor
queue::~queue() {
  delete [] _arr;
}

// add an element to the end of queue (expand if necessary)
void queue::enqueue(const TYPE a) {
  if (_size == _capacity) { // doubles it

      _capacity *= 2;
      //cout << _capacity << endl;
      TYPE * _arr2 = new TYPE[_capacity];
      for (int i = 0; i < _capacity/2; i++) {
        _arr2[i] = _arr[i];
      }

      delete [] _arr;
      _arr = _arr2;
      _arr[_front + _size] = a;


  } else if ((_front + _size) == _capacity) {
     int newi = 0;
     for (int i = _front; i < _size + _front; i++) {
       _arr[newi] = _arr[i];
       newi++;
     }
     for (int j = newi; j < _capacity; j++) {
       _arr[j] = 0;
     }
     _front = 0;
     _arr[_front + _size] = a;
  } else {
    _arr[_front + _size] = a;
  }
  _size++;
}

// remove an element from the front of queue
TYPE queue::dequeue() {
  if (_size == 0) {
    throw EmptyQueueException();
  }
  TYPE a = _arr[_front];
  _arr[_front] = 0;
  _front++;
  _size--;
  //cout << _size << endl;
  return a;
}

// access the element at queue front; does not remove the elemen
TYPE& queue::front() {
  return _arr[_front];
}

// return true if the queue is empty, false otherwise
bool queue::empty() {
  return (size() == 0);
}

// return the number of elements currently in the queue
int queue::size() {
  return _size;
}

// return the current capacity of the queue
int queue::capacity() {
  return _capacity;
}

// output queue elements from queue front to queue end
// elements are separated with a white space.
void queue::dump(ostream &os) {
  for (int i = 0; i < size(); i++) {
    os << _arr[i] << " ";
  }
  os << endl;
}
