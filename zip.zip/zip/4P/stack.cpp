#include <iostream>
#include <cassert>
using namespace std;
#include "stack.h"
#include <string>

stack::stack(int) {
  _arr = new TYPE[INITCAP];
  _tos = -1;
  _capacity = INITCAP;
}

stack::stack(const stack& arty) {
  // delete [] _arr;
  _arr = arty._arr;
  _arr = new TYPE[arty._capacity];
  _capacity = arty._capacity;
  _tos = arty._tos;
  for (int i = _tos; i >= 0; i--) {
    _arr[i] = arty._arr[i];
  }
}

stack& stack::operator=(const stack& arty) {
  delete [] _arr;
  _arr = arty._arr;
  _arr = new TYPE[arty._capacity];
  _capacity = arty._capacity;
  _tos = arty._tos;
  for (int i = _tos; i >= 0; i--) {
    _arr[i] = arty._arr[i];
  }
  return *this;
}

// destructor
stack::~stack() {
  delete [] _arr;
}

void stack::push(const TYPE x) {

  if (size() == _capacity) {

    _capacity *= 2;;
    TYPE * _arr2 = new TYPE[_capacity];

    for (int i = 0; i < _capacity/2; i++) {
      _arr2[i] = _arr[i];
    }

    delete [] _arr;
    _arr = _arr2;
  }
  _tos++;
  _arr[_tos] = x;
}


void stack::pop() {
  if (empty()) {
    throw EmptyStackException();
  }
  _arr[_tos] = 0;
  _tos--;
}

TYPE& stack::top() {
  return _arr[_tos];
}

bool stack::empty() {
  return (_tos == -1);
}

int stack::size() {
  return _tos + 1;
  //return 0;
}


int stack::capacity() {
  return _capacity;
}

void stack::dump(ostream &os) {
  for (int i = size()-1; i >= 0; i--) {
    os << _arr[i] << " ";
  }
  os << endl;
}
