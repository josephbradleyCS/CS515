#include "map.h"

int main(){
    Map<int, int> m; // Map template will be instanticated here
    m.insert(3, 5)
}
