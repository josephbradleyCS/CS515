int main(){
    char *p = new char[100];
}
