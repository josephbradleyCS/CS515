#include <iostream>
#include <cstdlib>
using namespace std;

/*  Interprets an integer value in a byte string pointed to by str.
    Function discards any whitespace characters until first non-whitespace
    character is found. Then it takes as many characters as possible to
    form a valid integer number representation and converts them to integer value.
    The valid integer value consists of the following parts:
        (optional) plus or minus sign
        numeric digits

    Parameters
        str	 -	 pointer to the null-terminated char string to be interpreted

    Return value: Integer value corresponding to the contents of str on success.
        If the converted value falls out of range of corresponding return type,
        the return value is undefined.
        If no conversion can be performed, 0 is returned.

*/

#include <iostream>
#include <cstdlib>
using namespace std;

int myatoi(const char * ptr){

   int nums[100];
   while(*ptr == ' '){
   ptr++;
   }

   int inti = 0;
   int end = 0;
   int neg = 0;
   int prn = *ptr;

   if(*ptr == 43 || *ptr == 45){
 	 if( *ptr == 45) {
   	neg = 1;
 	 }
  	ptr++;
   }

   while(*ptr != '\0' && end == 0){
       	if(*ptr < 58 && *ptr > 47){
               	nums[inti] = (*ptr-48);
               	inti++;
       	} else {end = 1;}
       	ptr++;
   }
   int ret = 0;
   int add = 0;
   for(int i = 0; i < inti; i++){
 	 int mmmyFactor = 1;
 	 for (int j = 1; j < (inti-i); j++) {
   	mmmyFactor = mmmyFactor *10;
 	 }
 	 add = nums[i] * mmmyFactor;
 	 ret = ret + add;

   }
   int tempy = 0;
   if(neg ==  1){
 	 tempy = ret;
 	 tempy = tempy - ret - ret;
 	 ret = tempy;
   }
  return ret;
}



// DO NOT ADD MAIN() FUNCTION IN THIS FILE
