int main(){
    int *p = new int[2];
    p[3]=100;
    delete [] p;
}
