#include <iostream>
#include <cstdlib>
using namespace std;

int* initArray(int);
int fillArray(int *, int);
int* doubleArray(int *, int);
void displayArray(int *, int);



int main(int argc, char ** argv){
    if (argc != 2){
        cout << "wrong number of arguments" << endl;
        exit(1);
    }

    int n = atoi(argv[1]); // get size
    srand(time(0));

    // create initial array and display it
    int* ptr = initArray(n);
    fillArray(ptr, n);
    displayArray(ptr, n);
    delete [] ptr;
    ptr = doubleArray(ptr, n);

    fillArray(ptr, 2*n);
    displayArray(ptr, 2*n);

    delete [] ptr;
    //delete tmp;
}

int* initArray(int n){
    int *ptr = new int[n];
    return ptr;
}

int fillArray(int *ptr, int n){
    for(int i=0; i<n; i++){
        ptr[i] = rand() % 100;
    }
    return 0;
}

// Double the size of the array, make sure no memory leak
int* doubleArray(int *ptr, int n){
    //delete ptr;
    int size = 2*n;
    int * tmp = new int[size];
    ptr = tmp;
     // delete
    return ptr;
}

// Display n array elements
void displayArray(int *ptr, int n){
    for(int i=0; i<n; i++){
        cout << ptr[i] << " ";
    }
    cout << endl;
}
