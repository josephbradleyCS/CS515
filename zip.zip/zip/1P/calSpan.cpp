
#include <string>       // std::string
#include <iostream>     // std::cout
#include <sstream>      // std::stringstream

#include <fstream>      // std::ifstream
#include <stdio.h>
#include <math.h>
using namespace std;



int main(int argc, char *argv[]){

  if (argc > 2 || argc == 1) { // checks if the fileName is in the command prompt
    cout << "Wrong number of arguments\n";
    // cout << 100;
    exit(1);
  }

  // line variable
  string line;

  // a stringstream reads in input and stores it
  stringstream ss;

  // file stream object
  ifstream fileIn;

  // opens the fileIn
  fileIn.open(argv[1]);
  if (!fileIn.is_open()) {
    cout << "Error opening file\n";
    exit(1);
  }

  // this will count the number of temps
  int i = 0;

  //gets the next space delimiated object and reads it to "line"
  while (getline(fileIn, line, ' ')) {
    // test to make sure works so far
    // cout << line << "\n";
    // reads lines into stringstream
    ss << line << "\n";
    // inclrement count of temps
    i++;
  }

  // sends bufffer to cout for check
  // cout << ss.rdbuf();

  // empty array with the correct amount of spots
  double arr[i] = { };

  // array to store the min high of each value, same index
  int arrTwo[i] = { };

  // iterate for the length of the amount of strings in the string stream
  for (int j = 0; j < i; j++) {

    // cout << isNumber(ss.str()) << "\n";
    bool storeStr = true;
    string str = " ";
    double val = 0;
    ss >> str;

    // if (str == " ") { // INFINTE LOOP POSSIBILITY
    //   continue;
    // }

    for (int cd = 0; cd < str.size(); cd++) {
      if (isalpha(str.at(cd)) && (str.at(cd) != '.' || str.at(cd) != '-')) {
        arr[j] = -101;
        storeStr = false;
        break;
      }
    }

    if (storeStr) {
      val = stod(str);
      arr[j] = val;
    }

    if (storeStr && val > 100 || val < -100) {
      arr[j] = -101;
      storeStr = false;
    }

    // if i havent made arr[j] something yet -> store stoiStr to arr[index j]

    // set all span values to 1
    arrTwo[j] == 1;


    //cout << arr[j] << "-> span == ";
    int high = arr[j];

    // for the amount of temps backwards
    // cout << "Span for [" << arr[j] << "]\n";
    for (int jk = j; jk >= 0; jk--) {
       // cout << "\t arr[jk] : [" << arr[jk] << "] arrTwo[jk] : [" << arrTwo[jk] << "]\n";
       if (arr[jk] == 0) {

       }
       if (arr[j] >= arr[jk]) {
         arrTwo[j]++;
       } else if (arr[jk - 1] == 0) {
         arrTwo[j]++;
       } else {
         break;
       }
    }
    // cout << arrTwo[j] << endl;
    // test to make sure the array has everything it should
    // cout << arr[j] << endl;
  }

  int minNum = 0;
  string a;
  bool flag = true;
  // io structured loop
  while (true) {
    cout << "Which minute to query? ";

    // store min in unsigned string
    cin >> a;
    if (a == "") {continue;}
    // checks to see if input == exit
    if (a == "exit" || a == "EXIt" || a == "Exit") {
      cout << endl;
      exit(0);
    } else {
      // if the input is not a
      for (int kj = 0; kj < a.size(); kj++) {
        if (!isdigit(a.at(kj))) {
          cout << "Wrong query input.\n";
          flag = false;
          break;
        }
      }

      if (!flag) {
        continue;
      }

      minNum = stoi(a);

      if (minNum < 0 || minNum >= i) {
        // throw
        cout << "Query minute out of range" << endl;
        continue;
      } else if (arr[minNum] == -101) {
        cout << "Data at minute " << minNum << " is corrupted.\n";
      } else {
        cout << "Data at minute "<< minNum <<" is a " << arrTwo[minNum] << "-minute(s) high." << endl;
        continue;
      }
    }
  }
  cout << endl;
  return 0;
}

// my method to see if its corrupted or not
