#include "unorderedmap.h"
#include <string>
using namespace std;

int main(){
   UnorderedMap <double, string> m; 
}
