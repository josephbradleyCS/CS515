int main(){
    char *p; 
    char c = *p;   
}
